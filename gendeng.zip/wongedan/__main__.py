from wongedan import *
from importlib import import_module
from wongedan.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("wongedan.modules." + module_name)
bot.run_until_disconnected()

