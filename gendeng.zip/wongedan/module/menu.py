def show_menu():
    print("1. Tampilkan IP VPS")
    print("2. Tambahkan IP VPS")
    print("3. Keluar")

def get_menu_choice():
    choice = input("Pilih menu: ")
    return choice
